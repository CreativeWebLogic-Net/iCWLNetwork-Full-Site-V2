<?php
// This file was auto-generated from sdk-root/src/data/appintegrations/2020-07-29/paginators-1.json
return [ 'pagination' => [],];
